<?php

/**
 * List the tool provided 
 *
 * @package   blocks
 * @subpackage  coursedetails
 * @copyright  2022  yamini
 */
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2022072700;        // The current plugin version (Date: YYYYMMDDXX)
$plugin->requires  = 2019072600;        // Requires this Moodle version
$plugin->component = 'block_coursedetails'; // Full name of the plugin (used for diagnostics)


