<?php
$string['coursedetails'] = 'Moodle test block';
$string['activityname'] = 'Activity details';