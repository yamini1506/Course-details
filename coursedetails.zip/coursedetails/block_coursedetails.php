<?php

/**
 * The coursedetails block
 *
 * @package    block
 * @subpackage    coursedetails
 * @copyright 2022 Yamini
 */

class block_coursedetails extends block_base {
	public function init() {
		$systemcontext = context_system::instance();
		global $USER,$DB,$CFG,$OUTPUT;
	
			$this->title = get_string('coursedetails', 'block_coursedetails');
		
		
	}
	public function get_content() {

		global $CFG, $PAGE, $OUTPUT, $DB, $USER;
	
		$this->content = new stdClass;
		$systemcontext = context_system::instance();
	    
	     $renderer = $PAGE->get_renderer('block_coursedetails');
			$coursecontent = $renderer->coursedetails_view();
		$this->content->text = $coursecontent;

		return $this->content;
	}
	function _self_test() {
  return true;
}

}
