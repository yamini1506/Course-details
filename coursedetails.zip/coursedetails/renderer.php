<?php
/**
* List the tool provided
*
* @package   block
* @subpackage  coursedetails
* @copyright  2022  Yamini
*/
global $DB, $OUTPUT, $USER, $CFG, $PAGE;
require_once dirname(dirname(dirname(__FILE__))) . '/config.php';
use core_component;

class block_coursedetails_renderer extends plugin_renderer_base {

	public function coursedetails_view() {
		global $DB, $PAGE, $USER, $CFG, $OUTPUT;
		$systemcontext = context_system::instance();
		$activitiesdata = $DB->get_records_sql("SELECT * FROM {course_modules} WHERE deletioninprogress = 0");
		$table = new html_table();
		$table->head = array(get_string('activityname', 'block_coursedetails'));
		if($activitiesdata){
			foreach ($activitiesdata as $activities) {

				$list = array();
				$id = $activities->id;
				$module_for_url = $DB->get_field('modules','name',array('id' => $activities->module));

				$sql = 'SELECT name FROM mdl_'.$module_for_url.' WHERE id ='.$activities->instance;
				$modulename = $DB->get_record_sql($sql);
				$completionstatus = $DB->get_field('course_modules_completion','timemodified',array('coursemoduleid'=>$id));

				if(empty($completionstatus) || $completionstatus == null){
					$completion = 'InProgress';
				}
				else if($completionstatus > 0){
					$completion = 'Completed';
				}
				$list[] = $id.'-<a href ="'.$CFG->wwwroot.'/mod/'.$module_for_url.'/view.php?id='.$id.'">'.$modulename->name.'</a>-'.gmdate("m-d-Y", $activities->added).'-'.$completion;

				$data[] = $list;        
			}
			$table->align = array('left');
			$table->width = '100%';
			$table->data = ($data) ? $data : 'No records';
			$table->id = 'advisor-studentslist';
			$output = html_writer::table($table);
		}else{
		$output .= '<div>
		<strong>No Data to display</strong>
		</div>';
		}
		return $output;
	}
}